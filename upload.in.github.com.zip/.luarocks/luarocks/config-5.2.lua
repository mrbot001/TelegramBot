rocks_trees = {
   { name = [[system]], root = [[/home/telegram/superflux/.luarocks]] }
}
